package com.example.bdbiblioteca1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.bdbiblioteca1.model.Livro;
import com.example.bdbiblioteca1.model.Usuario;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    Usuario cliente = new Usuario("Joaquim", "15", "Gerente");
    Usuario gerente = new Usuario("Paulo", "35", "Cliente");
    Livro livro = new Livro("Senhor dos anéis", "1a2b3c4d5e");
    livro.selecionar();
    }
}
